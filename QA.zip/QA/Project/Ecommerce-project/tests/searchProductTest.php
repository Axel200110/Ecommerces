<?php


require 'search_product.php'; // Ensure this path is correct relative to removedTest.php

use PHPUnit\Framework\TestCase;

class searchProductTest extends TestCase
{
    public function testsearchProductFunction() {
        // Pass an argument to removedFunction
        $result = searchProductFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = searchProductFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>